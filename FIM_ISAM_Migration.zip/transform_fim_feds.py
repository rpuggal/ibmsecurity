import lxml.etree as etree

## Edit filenames/paths below as necessary ##
#############################################
fed_name = "Saml20Idp"
output_filename = "./configure_fed_isam9.yml"
xml_filename = "./feds.xml"
xsl_filename = "./transform_fim_feds.xsl"

encryption_keystore = "rt_profile_keys"
encryption_key_label = "testkey"
signing_keystore = "rt_profile_keys"
signing_key_label = "testkey"
validation_keystore = "rt_profile_keys"
validation_key_label = "validation-1493571052732"
reverse_proxy_instance_name = "default"
aac_username = "easuser"
aac_password = "passw0rd"
#############################################

dom = etree.parse(xml_filename)
xslt = etree.parse(xsl_filename)
transform = etree.XSLT(xslt)
output = transform(dom, fedName=etree.XSLT.strparam(fed_name), signingKeystore=etree.XSLT.strparam(signing_keystore),
  signingKeyLabel=etree.XSLT.strparam(signing_key_label), validationKeystore=etree.XSLT.strparam(validation_keystore),
  validationKeyLabel=etree.XSLT.strparam(validation_key_label), encryptionKeystore=etree.XSLT.strparam(encryption_keystore),
  encryptionKeyLabel=etree.XSLT.strparam(encryption_key_label), reverseProxyInstance=etree.XSLT.strparam(reverse_proxy_instance_name),
  aacUsername=etree.XSLT.strparam(aac_username), aacPwd=etree.XSLT.strparam(aac_password))
file = open(output_filename, "w")
file.write(str(output))
print("New Ansible playbook created at " + output_filename)
