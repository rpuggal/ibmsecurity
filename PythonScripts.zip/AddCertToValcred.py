#!/usr/bin/python
# Adds Certificate to existing ValCred, pointing to the file in cert:///.
# It's generally best to upload the cert first.
# Ken Hygh khygh@us.ibm.com

import sys, httplib
import base64
import os,socket
from xml.dom.minidom import parseString
import zipfile
from optparse import OptionParser
from DPCommonFunctions import getText, showResults, setHeaders

# Get commandline options
parser = OptionParser("usage: %prog -z <parameterFilename> -s <device> -d <domain> -u <userid> -p <password> -v <valcred_name> -c <certName> -f <certFilename>")
parser.add_option("-d", "--domain", dest="domain", help="domain")
parser.add_option("-u", "--userid", dest="username", help="userid")
parser.add_option("-p", "--password", dest="password", help="password")
parser.add_option("-s", "--server", dest="server", help="datapower server name")
parser.add_option("-v", "--valcred", dest="valcred", help="ValCred Name")
parser.add_option("-c", "--cert", dest="cert", help="Cert Name")
parser.add_option("-f", "--file", dest="file", help="Cert filename")
parser.add_option("-z", "--parameterFile", dest="parameters", help="parameter filename")

(options, args) = parser.parse_args()

if options.parameters != None:
    try:
        options.read_file(options.parameters)
    except IOError:
        print "Could not open '" + options.parameters + "', exiting."
        sys.exit(4)

if options.domain == None:
    parser.error("no domain name supplied")
if options.username == None:
    parser.error("no userid supplied")
if options.password == None:
    parser.error("no password supplied")
if options.server == None:
    parser.error("no server name supplied")
if options.valcred == None:
    parser.error("no ValCred name supplied")
if options.cert == None:
    parser.error("No Cert name supplied")
    
# We can't just add a certificate to an existing valcred. We have
# to query the DP box, get the list of existing certs, and set all
# existing certs as well as our new one. Ugly.

# build the XML to request the existing certificate list
SM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dp="http://www.datapower.com/schemas/management">
  <soapenv:Header/>
    <soapenv:Body>
      <dp:request domain="%s">
        <dp:do-export format="XML" all-files="0">
          <dp:object class="CryptoValCred" name="%s"/>
        </dp:do-export>
      </dp:request>
    </soapenv:Body>
  </soapenv:Envelope>
"""
SoapMessage = SM_TEMPLATE%(options.domain,options.valcred)
#print SoapMessage
print "Getting current configuration..."
webservice = setHeaders(options.username,options.password,options.server, len(SoapMessage))
webservice.send(SoapMessage)

statuscode, statusmessage, header = webservice.getreply()
#print "Response: ", statuscode, statusmessage
res = webservice.getfile().read()
webservice.close()

# now, get the base64-encoded results, decode it
dom = parseString(res)
fileNodes = dom.getElementsByTagName("dp:file")
file = ''
for node in fileNodes[0].childNodes:
    if node.nodeType == node.TEXT_NODE:
        file += node.data

#print file
# now decode the base64-encoded stuff
unencoded = base64.decodestring(file)
#print unencoded

dom = parseString(unencoded)
nodes = dom.getElementsByTagName("CryptoValCred")
currentCertList = ''
for node in nodes[0].childNodes:
    #print 'h'
    if node.nodeType == node.ELEMENT_NODE and node.tagName == 'Certificate':
        currentCertList += '<Certificate class="CryptoCertificate">' + getText(node.childNodes) + '</Certificate>'
        #print getText(node.childNodes)

# point cert object to cert:///<baseFilename of cert file>
dpCertFilename = 'cert:///' + os.path.basename(options.file)

# Build the XML Management Interface payload to create objects.
# 1. set certs in ValCred
# 2. create Certificate object
# 3. save config
SM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dp="http://www.datapower.com/schemas/management">
  <soapenv:Header/>
    <soapenv:Body>
      <dp:request domain="%s">
        <dp:set-config>
         <CryptoValCred name="%s">
            %s
            <Certificate class="CryptoCertificate">%s</Certificate>
        </CryptoValCred>
        </dp:set-config>
      </dp:request>
      <dp:request domain="%s">
        <dp:set-config>
          <CryptoCertificate name="%s">
            <mAdminState>enabled</mAdminState>
             <Filename>%s</Filename>
              <PasswordAlias>off</PasswordAlias>
              <IgnoreExpiration>off</IgnoreExpiration>
           </CryptoCertificate>
        </dp:set-config>      
      </dp:request>
      <dp:request domain="%s">
        <dp:do-action>
          <SaveConfig/>
        </dp:do-action>
      </dp:request>
    </soapenv:Body>
  </soapenv:Envelope>
"""

SoapMessage = SM_TEMPLATE%(options.domain,options.valcred,currentCertList,options.cert,options.domain,options.cert,dpCertFilename,options.domain)
#print SoapMessage

print "Creating and adding certificate object..."
webservice = setHeaders(options.username,options.password,options.server, len(SoapMessage))
webservice.send(SoapMessage)

# get the response
statuscode, statusmessage, header = webservice.getreply()
#print "Response: ", statuscode, statusmessage
#print "headers: ", header

# res contains a SOAP wrapper and DP stuff wrapped around the response
res = webservice.getfile().read()
#print res

actions = ['AddCertToValcred','CreateCertObject']
showResults(res, actions)

print "Make sure you upload", options.file, "to", dpCertFilename