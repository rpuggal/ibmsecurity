#!/usr/bin/python
#
# Import zipped DataPower domain export
# 3/21/2012 Ken Hygh (khygh@us.ibm.com)
# 

import sys, httplib, os
import base64
from xml.dom.minidom import parseString
import StringIO, zipfile
from datetime import date
from optparse import OptionParser
from DPCommonFunctions import getText, showResults, setHeaders

# Get commandline options
parser = OptionParser("usage: %prog -s <device> -d <domain> -u <userid> -p <password>")
parser.add_option("-d", "--domain", dest="domain", help="domain")
parser.add_option("-u", "--userid", dest="username", help="userid")
parser.add_option("-p", "--password", dest="password", help="password")
parser.add_option("-s", "--server", dest="server", help="datapower server name")
parser.add_option("-f", "--file", dest="zipFilename", help="zipfile to import")
parser.add_option("-e", "--deployment-policy", dest="depPolicy", help="name of deployment policy")
parser.add_option("-z", "--parameterFile", dest="file", help="parameter filename")

(options, args) = parser.parse_args()
if options.file != None:
    try:
        options.read_file(options.file)
    except IOError:
        print "Could not open '" + options.file + "', exiting."
        sys.exit(4)
        
if options.domain == None:
    parser.error("no domain name supplied")
if options.username == None:
    parser.error("no userid supplied")
if options.password == None:
    parser.error("no password supplied")
if options.server == None:
    parser.error("no server name supplied")
if options.zipFilename == None:
    parser.error("no zip filename supplied")

# need to read in the zip file and base64 it
FILE = open(options.zipFilename,'rb')
zipContents = FILE.read()
encodedZip = base64.encodestring(zipContents)[:-1]
FILE.close()

print "importing " + options.zipFilename + " into domain " + options.domain

# do substitution into the payload XML we're sending to DataPower
deploymentPolicyAttribute = ''
if options.depPolicy != None:
    deploymentPolicyAttribute = 'deployment-policy="' + options.depPolicy + '"'
SM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dp="http://www.datapower.com/schemas/management">
  <soapenv:Header/>
    <soapenv:Body>
      <dp:request domain="%s">
        <dp:do-import source-type="ZIP" overwrite-files="true" overwrite-objects="true" rewrite-local-ip="false" %s>
            <dp:input-file>%s</dp:input-file>
        </dp:do-import>
      </dp:request>
      <dp:request xmlns:dp="http://www.datapower.com/schemas/management" domain="%s">
          <dp:do-action>
              <SaveConfig/>
          </dp:do-action>
      </dp:request> 
    </soapenv:Body>
  </soapenv:Envelope>
"""
SoapMessage = SM_TEMPLATE%(options.domain,deploymentPolicyAttribute,encodedZip,options.domain)

#construct and send the headers
webservice = setHeaders(options.username,options.password,options.server, len(SoapMessage))
webservice.send(SoapMessage)

# get the response

statuscode, statusmessage, header = webservice.getreply()
#print "Response: ", statuscode, statusmessage
#print "headers: ", header

# res contains SOAP 
res = webservice.getfile().read()
#print res

importResult = res[:res.rfind('<env:Envelope')]
saveResult = res[res.rfind('<env:Envelope'):]

# now to get the results


importDOM = parseString(importResult)
saveDOM = parseString(saveResult)
Nodes = importDOM.getElementsByTagName("file-copy-log")
print Nodes[0].toprettyxml(indent=" ")
Nodes = importDOM.getElementsByTagName("exec-script-results")
print Nodes[0].toprettyxml(indent=" ")
