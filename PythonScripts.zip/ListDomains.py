#!/usr/bin/python
# List Domains on a DP appliance

import sys, httplib
import base64
from xml.dom.minidom import parseString
from optparse import OptionParser

parser = OptionParser("usage: %prog")
parser.add_option("-u", "--userid", dest="username", help="userid")
parser.add_option("-p", "--password", dest="password", help="password")
parser.add_option("-s", "--server", dest="server", help="datapower server name")
parser.add_option("-z", "--parameterFile", dest="file", help="parameter filename")
(options, args) = parser.parse_args()

if options.file != None:
    try:
        options.read_file(options.file)
    except IOError:
        print "Could not open '" + options.file + "', exiting."
        sys.exit(4)    

SoapMessage = """<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <soap:Body>
        <mgmt:request xmlns:mgmt="http://www.datapower.com/schemas/management" domain="default">
            <mgmt:get-status class="DomainStatus" />
        </mgmt:request>
    </soap:Body>
</soap:Envelope>
"""
#print SoapMessage

#construct and send the headers
webservice = setHeaders(options.username,options.password,options.server, len(SoapMessage))
webservice.send(SoapMessage)

# get the response

statuscode, statusmessage, header = webservice.getreply()
#print "Response: ", statuscode, statusmessage
#print "headers: ", header

# res contains a SOAP wrapper and DP stuff wrapped around the base64-encoded response
res = webservice.getfile().read()
#print res

# now to get the string of base64 encoded stuff
dom = parseString(res)
fileNodes = dom.getElementsByTagName("DomainStatus")
for domainNode in fileNodes:
    nameNodes = domainNode.getElementsByTagName("Domain")[:1]
    name = nameNodes[0].childNodes[0].data
    print name
if len(fileNodes) == 0:
    resultNodes = dom.getElementsByTagName("dp:result")
    result = resultNodes[0].childNodes[0].data
    print result
