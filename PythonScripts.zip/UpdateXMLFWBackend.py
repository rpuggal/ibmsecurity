#!/usr/bin/python
# 
# Update XMLFW back-end URL
# Ken Hygh, khygh@us.ibm.com 6/14/2012

import sys, httplib
import base64
import os,socket
from xml.dom.minidom import parseString
import zipfile
from optparse import OptionParser
from DPCommonFunctions import getText, showResults, setHeaders

# Get commandline options
parser = OptionParser("usage: %prog -s <device> -d <domain> -u <userid> -p <password> -x <xmlFW_name> -a <newAddress>")
parser.add_option("-d", "--domain", dest="domain", help="domain")
parser.add_option("-u", "--userid", dest="username", help="userid")
parser.add_option("-p", "--password", dest="password", help="password")
parser.add_option("-s", "--server", dest="server", help="datapower server name")
parser.add_option("-x", "--xmlfw", dest="xmlfwName", help="XMLFW Name")
parser.add_option("-a", "--address", dest="address", help="new address")
parser.add_option("-z", "--parameterFile", dest="file", help="parameter filename")

(options, args) = parser.parse_args()

if options.file != None:
    try:
        options.read_file(options.file)
    except IOError:
        print "Could not open '" + options.file + "', exiting."
        sys.exit(4)
        
if options.domain == None:
    parser.error("no domain name supplied")
if options.username == None:
    parser.error("no userid supplied")
if options.password == None:
    parser.error("no password supplied")
if options.server == None:
    parser.error("no server name supplied")
if options.xmlfwName == None:
    parser.error("no XMLFW name supplied")
if options.address == None:
    parser.error("need new address")

SM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dp="http://www.datapower.com/schemas/management">
  <soapenv:Header/>
    <soapenv:Body>
      <dp:request domain="%s">
        <dp:modify-config>
            <XMLFirewallService name="%s">
                <RemoteAddress>%s</RemoteAddress>
            </XMLFirewallService>
        </dp:modify-config>
      </dp:request>
      <dp:request domain="%s">
        <dp:do-action>
          <SaveConfig/>
        </dp:do-action>
      </dp:request>
    </soapenv:Body>
  </soapenv:Envelope>
"""
    
SoapMessage = SM_TEMPLATE%(options.domain,options.xmlfwName,options.address,options.domain)
#print SoapMessage

webservice = setHeaders(options.username,options.password,options.server, len(SoapMessage))
webservice.send(SoapMessage)

# get the response

statuscode, statusmessage, header = webservice.getreply()
#print "Response: ", statuscode, statusmessage
#print "headers: ", header

# res contains a SOAP wrapper and DP stuff wrapped around the base64-encoded response
res = webservice.getfile().read()
#print res

# now to get the results
actions = ['UpdateXMLFW','SaveConfig']
showResults(res, actions)

