#!/usr/bin/python
#
# Exports DataPower domain
# Ken Hygh, khygh@us.ibm.com 6/14/2012

import sys, httplib, os
import base64
from xml.dom.minidom import parseString
import StringIO, zipfile
from datetime import date
from optparse import OptionParser
from DPCommonFunctions import getText, showResults, setHeaders

# Get commandline options
parser = OptionParser("usage: %prog -s <device> -d <domain> -u <userid> -p <password>")
parser.add_option("-d", "--domain", dest="domain", help="domain")
parser.add_option("-u", "--userid", dest="username", help="userid")
parser.add_option("-p", "--password", dest="password", help="password")
parser.add_option("-s", "--server", dest="server", help="datapower server name")
parser.add_option("-z", "--parameterFile", dest="file", help="parameter filename")
(options, args) = parser.parse_args()

if options.file != None:
    try:
        options.read_file(options.file)
    except IOError:
        print "Could not open '" + options.file + "', exiting."
        sys.exit(4)
        
if options.domain == None:
    parser.error("no domain name supplied")
if options.username == None:
    parser.error("no userid supplied")
if options.password == None:
    parser.error("no password supplied")
if options.server == None:
    parser.error("no server name supplied")

# perform substitution into XML we send to DataPower
SM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dp="http://www.datapower.com/schemas/management">
  <soapenv:Header/>
    <soapenv:Body>
      <dp:request domain="%s">
        <dp:do-export format="ZIP" all-files="true">
            <dp:object class="all-classes" name="all-objects" ref-objects="true" ref-files="true"/>
        </dp:do-export>
      </dp:request>
    </soapenv:Body>
  </soapenv:Envelope>
"""
SoapMessage = SM_TEMPLATE%(options.domain)
#print SoapMessage

webservice = setHeaders(options.username,options.password,options.server, len(SoapMessage))
webservice.send(SoapMessage)

# get the response

statuscode, statusmessage, header = webservice.getreply()
#print "Response: ", statuscode, statusmessage
#print "headers: ", header

# res contains a SOAP wrapper and DP elements wrapped around the base64-encoded response
res = webservice.getfile().read()
#print res

# now to get the string of base64 encoded stuff
dom = parseString(res)
fileNodes = dom.getElementsByTagName("dp:file")

file = ''
for node in fileNodes[0].childNodes:
        if node.nodeType == node.TEXT_NODE:
            file += node.data
#print file

# now decode the base64-encoded stuff
unencoded = base64.decodestring(file)
#print unencoded

# the following is sample code in case you want to get at export.xml within the zipped content
#zip = zipfile.ZipFile(StringIO.StringIO(unencoded))
#exportFile = zip.open("export.xml")
#config = exportFile.read()
#print config

# generate zip filename of format 'Export<domain>yyyymmdd.zip'
now = date.today()
zipFilename = now.strftime(options.domain + "Export20%y%m%d.zip")

# create output zip file
FILE = open(zipFilename,"wb")
FILE.write(unencoded)
FILE.close()
print "Created", zipFilename

