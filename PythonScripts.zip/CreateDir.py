#!/usr/bin/python
# Upload File
# 5/30/2012 Ken Hygh (khygh@us.ibm.com)
# 

import sys, httplib, os
import base64
from xml.dom.minidom import parseString
import StringIO
from datetime import date
from optparse import OptionParser
from DPCommonFunctions import getText, showResults, setHeaders

# Get commandline options
parser = OptionParser("usage: %prog -s <device> -d <domain> -u <userid> -p <password> -f <filename> -t <datapowerPath>")
parser.add_option("-d", "--domain", dest="domain", help="domain")
parser.add_option("-u", "--userid", dest="username", help="userid")
parser.add_option("-p", "--password", dest="password", help="password")
parser.add_option("-s", "--server", dest="server", help="datapower server name")
parser.add_option("-r", "--directory", dest="dir", help="directory to create")
parser.add_option("-t", "--path", dest="path", help="path on datapower")
parser.add_option("-z", "--parameterFile", dest="file", help="parameter filename")

(options, args) = parser.parse_args()

if options.file != None:
    try:
        options.read_file(options.file)
    except IOError:
        print "Could not open '" + options.file + "', exiting."
        sys.exit(4)
        
if options.domain == None:
    parser.error("no domain name supplied")
if options.username == None:
    parser.error("no userid supplied")
if options.password == None:
    parser.error("no password supplied")
if options.server == None:
    parser.error("no server name supplied")
if options.dir == None:
    parser.error("no directory name supplied")

print "creating " + options.dir + " into domain " + options.domain

# do substitution into the payload XML we're sending to DataPower
path = 'local:///'
relpath = ''
if options.path != None:
    path = options.path
SM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dp="http://www.datapower.com/schemas/management">
  <soapenv:Header/>
    <soapenv:Body>
      <dp:request domain="%s">
        <dp:do-action>
          <CreateDir>
          	<Dir>%s</Dir>
          </CreateDir>
        </dp:do-action>
      </dp:request>
    </soapenv:Body>
  </soapenv:Envelope>
"""
SoapMessage = SM_TEMPLATE%(options.domain,path + options.dir)
print SoapMessage
#exit(1)

webservice = setHeaders(options.username,options.password,options.server, len(SoapMessage))
webservice.send(SoapMessage)

# get the response

statuscode, statusmessage, header = webservice.getreply()
#print "Response: ", statuscode, statusmessage
#print "headers: ", header

# res contains a SOAP wrapper and DP elements 
res = webservice.getfile().read()
#print res

# now to get the results
actions = ['Create Dir']
showResults(res, actions)
