#!/usr/bin/python
# 9/12/2006, 6/14/2012 Ken Hygh khygh@us.ibm.com
#
# create new dp domain/usergroup/user
import sys, httplib, os, time
from xml.dom.minidom import parseString
import StringIO, base64 
from datetime import date
from optparse import OptionParser
import Tkinter as Tk
from DPCommonFunctions import getText, showResults, setHeaders

class MyDialog:
  def __init__(self, parent):
    top = self.top = parent
    top.title("Add Domain/User/Group")
    Tk.Label(top, text="Host").grid(row=0, column=0)
    self.host = Tk.Entry(top)
    self.host.grid(row=0, column=1)
    Tk.Label(top, text="admin userid").grid(row=1, column=0)
    self.login = Tk.Entry(top)
    self.login.grid(row=1, column=1)
    Tk.Label(top, text="admin password").grid(row=2, column=0)
    self.password = Tk.Entry(top)
    self.password.grid(row=2, column=1)
    Tk.Label(top, text="Domain").grid(row=3, column=0)
    self.domain = Tk.Entry(top)
    self.domain.grid(row=3, column=1)
    Tk.Label(top, text="userName").grid(row=4, column=0)
    self.user = Tk.Entry(top)
    self.user.grid(row=4, column=1)
    Tk.Label(top, text="Comment").grid(row=5, column=0)
    self.email = Tk.Entry(top)
    self.email.grid(row=5, column=1)
    
    Tk.Button(top, text="OK", command=self.ok).grid(row=7, column=0)
    self.host.focus_set()
    top.update()
      
  def ok(self):
    self.top.quit()

#
# MAIN()
#
# Get commandline options
parser = OptionParser("usage: %prog -z <parameterFile> -s <device> -u <userid> -p <password> -d <newDomain> -n <newUser> -c <comment>")
parser.add_option("-d", "--domain", dest="domain", help="new domain")
parser.add_option("-u", "--userid", dest="username", help="userid")
parser.add_option("-p", "--password", dest="password", help="password")
parser.add_option("-s", "--server", dest="server", help="datapower server name")
parser.add_option("-n", "--newUser", dest="newUser", help="new userid")
parser.add_option("-c", "--comment", dest="comment", help="object comment")
parser.add_option("-z", "--parameterFile", dest="file", help="parameter filename")
(options, args) = parser.parse_args()

if options.file != None:
    try:
        options.read_file(options.file)
    except IOError:
        print "Could not open '" + options.file + "', exiting."
        sys.exit(4)

host=options.server
domain=options.domain
username=options.username
password=options.password
user=options.newUser
email=options.comment

# pop up dialog if no arguments were passed in.  
if host==None or domain==None or username==None or password==None or user==None:
  root = Tk.Tk()
  d = MyDialog(root)
  if host != None:
      d.host.insert(0,host)
  if domain != None:
      d.domain.insert(0,domain)
  if username != None:
      d.login.insert(0,username)
  if password != None:
      d.password.insert(0,password)
  if user != None:
      d.user.insert(0,user)
  if email != None:
      d.email.insert(0,email)      
  root.mainloop()
  host = d.host.get()
  username = d.login.get()
  password = d.password.get()
  domain = d.domain.get()
  user = d.user.get()
  email = d.email.get()

group = user + 'Group'
#
# MAIN()
#
today = time.strftime('%Y/%m/%d')

SM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
    <env:Body>
        <dp:request xmlns:dp="http://www.datapower.com/schemas/management" domain="default">
            <dp:set-config>
                <Domain name="%s">
                    <UserSummary>%s %s</UserSummary>
                    <NeighborDomain class="Domain">default</NeighborDomain>
                </Domain>
            </dp:set-config>
        </dp:request>
        <dp:request xmlns:dp="http://www.datapower.com/schemas/management" domain="default">
            <dp:set-config>
                <UserGroup name="%s">
                    <UserSummary>%s %s</UserSummary>
                    <AccessPolicies>*/%s/*?Access=r+w+a+d+x</AccessPolicies>
                    <CommandGroup>configuration</CommandGroup>
                    <CommandGroup>common</CommandGroup>
                </UserGroup>
            </dp:set-config>
        </dp:request>
        <dp:request xmlns:dp="http://www.datapower.com/schemas/management" domain="default">
            <dp:set-config>
                <User name="%s">
                    <Password>%s</Password>
                    <GroupName>%s</GroupName>
                    <AccessLevel>group-defined</AccessLevel>
                    <UserSummary>%s %s</UserSummary>
                </User>
            </dp:set-config>
        </dp:request>
        <dp:request xmlns:dp="http://www.datapower.com/schemas/management" domain="default">
            <dp:modify-config>
                <Domain name="%s">
                    <DomainUser class="User">%s</DomainUser>
                </Domain>
            </dp:modify-config>
        </dp:request>
        <dp:request xmlns:dp="http://www.datapower.com/schemas/management" domain="default">
            <dp:do-action>
                <SaveConfig/>
            </dp:do-action>
        </dp:request>
    </env:Body>
</env:Envelope>
"""
SoapMessage = SM_TEMPLATE%(domain,email,today,group,email,today,domain,user,user,group,email,today,domain,user)
#print SoapMessage

#construct and send the headers. First, build the BasicAuth header content
webservice = setHeaders(username,password,host, len(SoapMessage))
webservice.send(SoapMessage)

# get the response
statuscode, statusmessage, header = webservice.getreply()
#print "Response: ", statuscode, statusmessage
#print "headers: ", header

# res contains a SOAP wrapper and DP elements wrapped around the base64-encoded response
res = webservice.getfile().read()
#print res

if statuscode == 200:
  print user +","
  print "I've created a domain for you on " + host + "."
  print "https://" + host + ":9090"
  print "\nuserid: " + user
  print "password: " + user + " (you'll be forced to change it your first login)"
  print "domain: " + domain
  print "\nPlease"
  print "1) select an unused port range for your artifacts"
  print "2) keep your domain backed-up, in case we need to reset the box"
  print "\nPlease let me know if you no longer need this access."

